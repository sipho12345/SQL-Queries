Select distinct salesRepEmployeeNumber,count(customerNumber) AS numCustomers
From  customers
Where salesRepEmployeeNumber In (Select employeeNumber From employees Where reportsTo = 1143)
Group By salesRepEmployeeNumber Having count(customerNumber) >= 10;