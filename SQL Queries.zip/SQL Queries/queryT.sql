Select "YES" As anyProblems
from orderdetails, products
where exists( select priceEach,buyprice from orderdetails,products where buyPrice = 0 OR priceEach = 0)
limit 1;