Select O.orderNumber,O.status,OD.priceEach,OD.quantityOrdered,pro.productName
FROM orders O
INNER JOIN orderdetails OD on 
O.orderNumber = OD.orderNumber
INNER JOIN products pro
on OD.productCode = pro.productCode
where productVendor = "Exoto Designs";