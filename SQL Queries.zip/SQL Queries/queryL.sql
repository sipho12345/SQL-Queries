SELECT O.orderNumber,O.comments,C.customerName
FROM orders O
INNER JOIN customers C on
O.customerNumber = C.customerNumber
WHERE status = "Disputed";