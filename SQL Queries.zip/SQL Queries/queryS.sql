Select customerNumber
From payments
where amount = (Select max(amount) from payments);