Select S.country,S.officeCode as oneOffice,SS.officeCode as otherOffice
from offices as S
cross join offices as SS
where S.officeCode < SS.officeCode and S.country = SS.country;